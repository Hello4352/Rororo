# 축제 게임 부스 페이지

## 파일 구성

```text
festival_game_zone/
├── index.html       # 메인 화면
├── lotto.html       # 로또 추첨 화면
├── css/
│   ├── style.css    # 메인 화면 디자인
│   └── lotto.css    # 로또 화면 디자인
└── js/
    ├── config.js    # 직접 수정하는 문구와 게임 설정
    ├── main.js      # 메인 화면 동작
    └── lotto.js     # 로또 추첨 동작
```

## GitHub Pages에 올리는 방법

1. GitHub에서 사용할 저장소(repository)를 엽니다.
2. 위 폴더 안의 파일과 폴더를 같은 구조로 저장소 최상위에 업로드합니다. `index.html`이 저장소 최상위에 있어야 합니다.
3. 저장소의 **Settings → Pages**로 이동합니다.
4. 배포 원본을 **Deploy from a branch**, 브랜치를 **main**, 폴더를 **/(root)**로 선택하고 저장합니다.
5. 배포된 사이트 주소를 열면 메인 화면이 나오고, 로또 추첨 버튼을 누르면 `lotto.html`로 이동합니다.

## 문구와 설명 수정하기

`js/config.js`를 열어 수정합니다.

- `siteTitle`, `siteSubtitle`: 메인 화면 제목과 안내 문구
- `descriptionCards`: 게임 설명 버튼 4개의 제목과 설명
- `productInfo`: 상품 안내 버튼의 제목과 설명
- `miniGames`: 미니게임 버튼의 이름
- `LOTTO_CONFIG`: 로또 화면의 문구와 추첨 시간

예를 들어 첫 번째 설명을 수정하려면 다음처럼 바꿉니다.

```js
{
  title: "참여 방법",
  description: "여기에 게임 방법을 적으세요.\n두 번째 줄도 입력할 수 있습니다."
}
```

미니게임 버튼은 현재 자리만 만들어 둔 상태이며 실제 게임 기능은 연결되어 있지 않습니다.

## 로또 설정

`js/config.js`의 `LOTTO_CONFIG`에서 다음 값이 적용되어 있습니다.

```js
countdownSeconds: 3,
revealInterval: 2800,
lastNumberPause: 2800
```

소리 기능은 포함하지 않았습니다. 번호는 1~45 중 중복 없이 6개를 뽑으며, 무작위 추첨에는 브라우저의 `crypto.getRandomValues()`를 사용합니다. GitHub Pages처럼 HTTPS로 제공되는 환경에서 실행하세요.
